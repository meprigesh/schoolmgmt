// File - Create, Read, Write, Delete, move, copy
// Directory/Folder - Create, Delete, Move, Copy

public class FileIO
{
    string rootPath = @"D:\Apps\CSharpFundamentals-Bishnu\CSharpBasics\FileIOTest";

    public void LearnFileHandling()
    {
        string filePath = $@"{rootPath}\abc.txt";

        File.WriteAllText(filePath, "This is first line");
        File.AppendAllText(filePath, "\nThis is second line");
        //File.Delete(filePath);

        FileInfo fi = new FileInfo(filePath);
        Console.WriteLine($"File Name: {fi.FullName}");
        Console.WriteLine($"Created: {fi.CreationTime}");
        Console.WriteLine($"Modified: {fi.LastWriteTime}");
        Console.WriteLine($"Size: {fi.Length} bytes");
    }

    public void LearnFolderHandling()
    {
        string folderPath = $"{rootPath}\\abc";
        Directory.CreateDirectory(folderPath);

        // Create C# file in this folder
        string filePath = $@"{folderPath}\abc.cs";
        File.WriteAllText(filePath, "//This is first line");
    }
}