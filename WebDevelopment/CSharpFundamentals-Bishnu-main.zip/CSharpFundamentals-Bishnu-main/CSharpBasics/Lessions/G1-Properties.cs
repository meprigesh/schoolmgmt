class Animal
{   
    string name;

    // Full property definition
    public string Name
    {
        get
        {
            return name;
        }
        set
        {
            if(value != "")
                name = value;
        }
    }

    // Readonly property
    public byte NoOfLegs { get; }
    
    // Autoimplemented property
    public string ScientificName { get; set; }
    public string ScientificName1 { get; private set; }
}
