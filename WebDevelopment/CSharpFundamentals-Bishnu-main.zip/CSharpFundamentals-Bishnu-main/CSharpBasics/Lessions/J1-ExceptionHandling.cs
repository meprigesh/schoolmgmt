public class ExceptionHandling
{
    public void CreateDictionary()
    {
        try
        {
            Dictionary<string, int> countryPopulation = new();
            countryPopulation.Add("Nepal", 2342234);
            countryPopulation.Add("India", 122342234);
            countryPopulation.Add("Russia", 2112234);
            countryPopulation.Add("China", 234234223);

            countryPopulation.Remove("China");

            foreach (var item in countryPopulation)
            {
                Console.WriteLine($"{item.Key} -> {item.Value}");
            }
        }
        catch(IOException ex)
        {
            Console.WriteLine(ex.Message ?? ex.InnerException.Message); // Null Coalescing operator
        }
        catch(Exception ex)
        {
            Console.WriteLine(ex.Message ?? ex.InnerException.Message); // Null Coalescing operator
        }
        finally
        {
            Console.WriteLine("Code block executed, Thank you!!!");
        }
    }
}