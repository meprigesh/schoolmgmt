public class Generic
{
    public void Print<T>(T info)
    {
        Console.WriteLine(info);
    }

    public void Print<T, U>(T info, U info1)
    {
        Console.WriteLine(info);
        Console.WriteLine(info1);
    }
}