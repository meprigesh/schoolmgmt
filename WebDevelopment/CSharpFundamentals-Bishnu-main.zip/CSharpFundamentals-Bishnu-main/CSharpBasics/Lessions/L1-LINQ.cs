// Language INtegrated Query (LINQ)
public class LINQ
{
    int[] numbers = { 2, 3, 45, 12, 23, 30, 45, 70, 43, 32 };
    List<string> names = new() { "bishakha", "Gynendra", "Ajay", "Susan", "Sanam", "Sangam", "Prigesh" };
    
    List<Person> people = new()
    {
        new Person { firstName = "", lastName = "", age = 12},
        new Person { firstName = "", lastName = "", age = 30},
        new Person { firstName = "", lastName = "", age = 12},
        new Person { firstName = "", lastName = "", age = 50},
        new Person { firstName = "", lastName = "", age = 12},
        new Person { firstName = "", lastName = "", age = 12}
    };
    
    public void LearnLinq()
    {
        // 1. Get all odd numbers from array "numbers"

        // Filters
        var oddNums = numbers.Where(num => num % 2 != 0); //Method Syntax

        oddNums = from num in numbers   // Expression Syntax
                  where num % 2 != 0
                  select num;           // Contextual Keywords: from, where, select

        // 1.1 Get all numbers which are multiple of 3 and 5
        var multipleOf3n5 = numbers.Where(num => num % 3 == 0 && num % 5 == 0);
        Print(multipleOf3n5);
        // 2. Get squares of all the numbers in array "numbers"

        //Projections
        var squares = numbers.Select(num => num * num);

        // 2.1 Get square root of each element on "numbers"
        var squareRoots = numbers.Select(x => Math.Sqrt(x));
        Print(squareRoots);

        // 1.2 Fetch all names from list "names" which starts from letter A or B
        var namesStartingAorB = 
            names.Where(name => name.ToUpper().StartsWith("A") || name.ToUpper().StartsWith("B"));
        Print(namesStartingAorB);

        // 3. Skip and Take
        var firstFive = names.Take(5);
        var ignoreFirst2Get2 = names.Skip(2).Take(2);

        // 1.3 Get all person older than 20 years.
        var p = people.Where(x => x.age > 20);

        var a1 = numbers.Min();
        var a2 = numbers.Max();
        var a3 = numbers.Average();
        var a4 = people.OrderByDescending(x => x.firstName);
        var a5 = people.GroupBy(x => x.age);
    }

    private void Print<T>(IEnumerable<T> nums)
    {
        Console.WriteLine("Printing result...");
        foreach(var item in nums)
        {
            Console.Write($"{item} ");
        }
        Console.WriteLine();
    }
}