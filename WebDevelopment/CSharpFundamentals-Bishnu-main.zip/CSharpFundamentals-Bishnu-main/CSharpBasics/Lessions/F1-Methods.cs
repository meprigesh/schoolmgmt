public class Methods
{
    //1. Returns nothing and take no arguments
    public void Print()
    {
        Console.WriteLine("I am from Nepal");
    }

    //2. Returns something and takes no arguments
    public string GetAddress()
    {
        string address = "Kathmandu, Nepal";
        return address;
    }

    //3. Returns something and take some arguments
    internal double Add(double x, int y)
    {
        var sum = x + y;
        return sum;       
    }

    // 3. Method overloading (Polymorphism)
    internal float Add(double x, int y, float z)
    {
        return (float)x + y + z;               
    }

    // 4. Variable number of arguments
    internal double Add(params double[] numbers)
    {
        var sum = 0.0;
        foreach(var num in numbers)
        {
            sum = sum + num;
        }

        return sum;       
    }   

    // 5. Optional arguments
    internal string GetFullName(string firstName, string lastName, string salutation = "Mr")
    {
        string fn = $"{salutation}. {lastName}, {firstName}";
        return fn;
    } 

    // 6. Expression bodied members
    internal float Add(int x, int y, float z) => (float)x + y + z; 
    double Multiply(double x, double y) => x * y;
     
    //7. Tuples
    internal (float, float) GetSumAndProduct(float a, float b)
    {
        var product = a * b;
        float sum = a + b;

        return (product, sum);    
    }

    internal (double, double) GetCircleDetails(double radius)
    {
        // Your code here
        // Area and perimeter  
        return (0, 0);
    }

    internal (short, short) GetMinMax(short[] numbers) // [4,2,6,8,10]
    {
        short min = 32767, max = 0;
        
        // find miminum and maximum among numbers
        foreach(var num in numbers)
        {
            if(min > num)
                min = num;
            
            if(max < num)
                max = num;
        }

        return (min, max);
    }

}