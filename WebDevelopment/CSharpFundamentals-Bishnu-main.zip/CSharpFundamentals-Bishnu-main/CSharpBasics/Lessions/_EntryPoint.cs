﻿using Inheritance;
using Shape;

class EntryPoint
{
    public static void Main()
    {
        // // Create object/ Instantiate / Create Instance
        // Person sangam = new();

        // // Set sangam's (object) data
        // sangam.firstName = "Sangam";
        // sangam.lastName = "Neupane";
        // sangam.age = 23;
        // sangam.isFemale = false;

        // // Create object/ Instantiate / Create Instance
        // Person susan = new() 
        // {
        //     firstName = "Susan",
        //     lastName = "Neupane",
        //     age = 23,
        //     isFemale = true
        // };

        // // Call object method
        // sangam.SpeakLanuage();

        // Branching b = new();
        // b.LearnBranching();

        // Loop l = new();
        // l.LearnLoops();

        // string firstName = "Ram";
        // string middleName = "Hari";
        // string lastName = "Basnet";

        // string fullName = firstName + " " + middleName + " " + lastName;

        // // string interpolation
        // string fullName1 = $"{firstName} {middleName} {lastName}";
        // Console.WriteLine(fullName);
        // Console.WriteLine(fullName1);

        // // Verbatim character
        // string countryDescription = @"Nepal \n is \n sdfsfssff. \nshdkhfkjsfdh \n fkjsfhskjfsh fkjsf";
        // Console.WriteLine(countryDescription);

        //Methods m = new();
        // var s = m.Add(23, 45);
        // var s1 = m.Add(352, 245);
        // var s2 = m.Add(232432.234, 452342);
        // var s3 = m.Add(23234.12, 43252325);

        // var s4 = m.Add(24, 23234, 43252325);
        // var s5 = m.Add(24, 23234, 43252325, 32234, 234242, 35253, 34535, 34535);

        // // Named arguments
        // var fn = m.GetFullName(lastName: "Rawal", firstName: "Bishnu");
        // var (p, s) = m.GetSumAndProduct(34.5f, 78.9f);
        // Console.WriteLine(p);

        // short[] numbers = { 4, 5, 6, 7, 1, 2, 90, 34, 45, 23 };

        // var (min, max) = m.GetMinMax(numbers);
        // Console.WriteLine($"Min: {min}");
        // Console.WriteLine($"Max: {max}");

        // Animal dog = new();
        // dog.Name = "abc"; //Set
        // // dog.ScientificName1 = "";
        // var x = dog.Name;   //get
        // var y = dog.NoOfLegs;


        // Animal cat = new();
        // cat.Name = "Kitty";

        // Truck v1 = new();
        // v1.Mileage = 12.3f;
        // v1.VNumber = "Ba. Pa. 23 2345";
        // v1.load = 10.5;
        // v1.Print();

        // Car v2 = new();
        // v2.Mileage = 12.3f;
        // v2.VNumber = "Ba. Pa. 23 2345";
        // v2.load = 10.5;
        // v2.Print();

        // Car c1 = new();
        // c1.PrintCarFeatures();

        // IEngine t1 = new Truck();
        // t1 = new Car();

        // Truck truck1 = new();
        // truck1.Print();

        // IShape rect1 = new Rectangle(3.4, 1.2);       
        // var a = rect1.GetArea();
        // var p = rect1.GetPerimeter();

        // Square sq1 = new(5.6);        
        // var a1 = sq1.GetArea();
        // var p1 = sq1.GetPerimeter();

        // Circle circle1 = new(5.6);        
        // var a2 = sq1.GetArea();
        // var p2 = sq1.GetPerimeter();

        // Generic g = new();
        // g.Print<short>(56);
        // g.Print(56355.353533545353534m);
        // g.Print("56");

        // g.Print<char, int>('5', 67);


        // Collection c = new();
        // c.LearnDs();

        // ExceptionHandling e = new();
        // e?.CreateDictionary(); // Null conditional operator
        // try
        // {
        //     int x = 30;
        //     if (x <= 50)
        //     {
        //         throw new Exception("X can't be less than 50.");
        //     }
        //     else
        //     {

        //     }
        // }
        // catch(Exception e)
        // {
        //     Console.WriteLine(e.Message);
        // }

        // FileIO f = new();
        // f.LearnFolderHandling();

        // LINQ l = new();
        // l.LearnLinq();

        ParallelAndAsync ps = new();
        ps.Do();
        ps.DoParallel();
    }
}
