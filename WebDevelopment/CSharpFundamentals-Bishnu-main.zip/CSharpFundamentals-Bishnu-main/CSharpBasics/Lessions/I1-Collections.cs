public class Collection
{
    //Datastructure: Stack, Queue, List, Dictionary
    public void LearnDs()
    {
        // Stack
        Stack<string> pile = new();
        pile.Push("Plate1");
        pile.Push("Plate2");
        pile.Push("Plate3");
        pile.Push("Plate4");

        pile.Pop();

        // Queue
        Queue<decimal> line = new();
        line.Enqueue(34.6m);
        line.Enqueue(41.7m);
        line.Enqueue(4.6m);

        line.Dequeue();

        // List
        List<string> names = new();
        names.Add("Bishnu");
        names.Add("Bishakha");
        names.Add("Gynendra");
        names.Add("Susan");

        names.Remove("Bishnu");
        var x = names[1];

        List<byte> ages = new() { 12, 23, 34, 45, 56 };
        var y = ages[3];

        //Dictionary        
        Dictionary<string, int> countryPopulation = new();
        countryPopulation.Add("Nepal", 2342234);
        countryPopulation.Add("India", 122342234);
        countryPopulation.Add("Russia", 2112234);
        countryPopulation.Add("China", 234234223);

        countryPopulation.Remove("China");

        foreach (var item in countryPopulation)
        {
            Console.WriteLine($"{item.Key} -> {item.Value}");
        }
    }
}


// ASP
// .NET Framework - Early 2000, Mono 
// ASP.NET - Web forms
// MVC - ASP.NET MVC 1 : late 2000

//.NET Core 1 - 2016, .NET Core 3.1
// ASP.NET Core: MVC, Razor Pages, Blazor (SPA)

//2020 - .NET 5
// .NET 6
