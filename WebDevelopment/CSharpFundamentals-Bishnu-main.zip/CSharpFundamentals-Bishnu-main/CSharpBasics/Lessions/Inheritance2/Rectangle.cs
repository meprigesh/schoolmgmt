namespace Shape;
public class Rectangle: IShape
{
    // Default parameterless constructor
    // public Rectangle()
    // {
    // }

    // Parameterized constructor
    public Rectangle(double l, double b)
    {
        length = l;
        breadth = b;
    }

    double length, breadth;

    public double GetArea() => length * breadth;
    public double GetPerimeter() => 2 * ( length + breadth);
}
