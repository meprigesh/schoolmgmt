namespace Shape;
public class Square: Rectangle
{
    public Square(double l): base(l, l)
    {        
    }
}
