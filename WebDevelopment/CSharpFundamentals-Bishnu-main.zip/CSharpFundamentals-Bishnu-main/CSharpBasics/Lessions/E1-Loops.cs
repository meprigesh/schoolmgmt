public class Loop
{
    public void LearnLoops()
    {
        // //for
        // for (int i = 1; i <= 10; i++)
        // {
        //     Console.WriteLine(i + ". Nepal is beautiful country.");
        // }

        // // while
        // int j = 1;
        // while (j <= 10)
        // {
        //     Console.WriteLine(j + ". Nepal is beautiful country.");
        //     j++;
        // }

        // //while
        // string cont = "y";
        // while (cont == "y")
        // {
        //     // do task
        //     Console.WriteLine("Hello there!!!");

        //     Console.Write("Continue?");
        //     cont = Console.ReadLine();
        // }

        // // do-while
        // string cont1 = "y";
        // do
        // {
        //     // do task
        //     Console.WriteLine("Hello there!!!");

        //     Console.Write("Continue?");
        //     cont1 = Console.ReadLine();
        // } while (cont1 == "y");

        //foreach
        byte[] ages = { 12, 23, 45, 56, 78, 90, 32, 43, 54, 65 };

        byte[,] table = { { 12, 23, 45 }, { 56, 78, 90 }, { 32, 43, 54 } };

        for (int i = 0; i < 3; i++)
        {            
            for (int j = 0; j < 3; j++)
            {
                Console.Write(table[i, j] + " ");
            }
            Console.WriteLine();
        }

        // foreach(byte age in ages)
        // {
        //     Console.Write($"{age} ");
        // }
    }
}
