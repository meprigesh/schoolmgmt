namespace Inheritance;
public class Vehicle
{
    public string VNumber { get; set; } = "N/A";
    public float Mileage { get; set; }
    public double load;

    public void Print()
    {
        var vechicleInfo = $"\nPlate: {VNumber} \nMileage: {Mileage} km/ltr \nCapacity:{load} tons";
        Console.Write(vechicleInfo);
    }

    public virtual string GetVendor()
    {
        return "TaTa";
    }
}
