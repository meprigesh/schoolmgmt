namespace Inheritance;
class ECar: Car
{
    
}
