// Inherits class
// Implements interface

namespace Inheritance;

class Truck: Vehicle, IEngine
{
    public new void Print()
    {
        
    }

    public override string GetVendor()
    {
        var x = base.GetVendor() + ", Ashok Leyland"; 
        return x;
    }

    public void ListParts()
    {
    }

    public void Start()
    {
    }
}
