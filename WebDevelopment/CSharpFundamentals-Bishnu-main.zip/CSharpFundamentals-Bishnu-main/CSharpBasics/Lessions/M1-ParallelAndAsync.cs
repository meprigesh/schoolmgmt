// Parallel Programming: Thread (Multithreading)
// Aynchronous Programming

using System.Diagnostics;

public class ParallelAndAsync
{
    public void Do()
    {
        Stopwatch sw = Stopwatch.StartNew();
        Console.WriteLine("Doing it in sequence...");
        for (int i = 1; i <= 20; i++)
        {
            DoTask(i);
        }
        var timeTaken = sw.ElapsedMilliseconds;
        Console.WriteLine($"Time elapsed: {(double)timeTaken / 1000} Seconds");
    }
    public void DoParallel()
    {
        Stopwatch sw = Stopwatch.StartNew();
        Console.WriteLine("Doing it in parallel...");
        Parallel.For(1, 21, (int i) => {
            DoTask(i);
        });
        var timeTaken = sw.ElapsedMilliseconds;
        Console.WriteLine($"Time elapsed: {(double)timeTaken / 1000} Seconds");
    }

    private void DoTask(int n)
    {
        Console.WriteLine($"Started task for {n}");
        // Simulating 1s task
        Thread.Sleep(1000);
        Console.WriteLine($"Completed task for {n}");
    }

    // Async-await

    public async Task<string> DoSomething()
    {
        //File.WriteAllText("sfasf", "sdfasfsaf");

        await File.WriteAllTextAsync("sfsf", "text");

        // //task1
        // await Task.Delay(2000);
        
        // //task2        
        // await Task.Delay(2000);

        // //task3
        // await Task.Delay(2000);

        return string.Empty;
    }
}
