class Solution
{
    void CheckEvenOdd()
    {
        //your code here
    }

    void CheckSimpleInterest()
    {
        //your code here
    }
}