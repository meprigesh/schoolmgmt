1. Check if number variable is even or odd?
1. Calculate simple interest and check if interest surpasses principal amount.

1. Write a method which takes number array as parameter and returns mimimum and maximum among all.

1. Inheritance
    1. We need to calculate area and perimeter of differet 2D shapes namely Rectangle, Square, Circle and Triangle. Design classes and thier hierarchies for this application.