# Installations
1. .NET SDK 6
1. VS Code and C# extension
1. Git
1. Github Account
    1. Create repository on github organization

# Assignments
1. Write a C# program to get user address and print that address on console in upper case.

1. Declare and initialize variables to represent age, name, gender and weight of a person. Gender of that person should be nullable.

1. Create C# class **Employee** with at least 5 fields and two methods in it. Instantiate **Employee** in differet class, assign object data and call methods to print output in console.

1. Print odd numbers less than 1000.
1. Print multiplication table for 5.
    ```
    Output:
    5 x 1 = 5
    5 x 2 = 10
    5 x 3 = 15
    ...
    ```
1. Print following patterns in console:
    ```
    #
    ##
    ###
    ####
    #####
    ######

    1
    12
    123
    1234
    12345
    123456

        #
       ###
      #####
     #######
    #########

         1
        123
       12345
      1234567
     123456789
    ```
1. Write a class as sensible as possible with 3 methods:
    1. Method 1 must take 2 parameters and returns string.
    1. Method 2 take no parameters and returns Datetime.
    1. Method 3 is overload of method 1 and takes 4 parameters.

1. Write a C# class with following members:
    1. Four methods:
        1. Method 1 takes 2 arguments and is not visible outside of containing class
        2. Method 2 takes date of birth as parameter and returns age of a person
        3. Method 3 takes number array as parameter and returns mean and median of given numbers.
        4. Overload of Method 3, takes two number arrays and merge both in ascending order. 
    2. Three fields: one visible within a class, one visible at project level and one can be accessed across multiple projects

1. Think of a real-life scenario where you can design your classes and interfaces as in the diagram below:
![alt text](/CSharpBasics/Classwork/ClassDiagram.png)

Also make sure,
>1. Base class 1 have a method that can be overriden by child classes  
>1. Base class 1 does not allow its instantiation.
>1. Base class 2 have a method that must be overriden by child classes1. 
>1. Child class 1 have a method that hides a parent method.
>1. Child class 2 have a propery that hides a property in a parent class.
>1. Child class 2 have a method that is overriden and uses base class implementation of that method as well.
>1. Grand child protect itself from getting inherited.
>1. Show case all the use-cases above in Main().

1. Create 10 folders in a rootfolder. Each folder should contain a text file containing a unique country name and its capital.

## Web Development
1. Create a asp.net core mvc app, add new contoller and two actions within.
    1. First action view should print numbers from 1-1000
    1. Second action view should render a bootstrap table


