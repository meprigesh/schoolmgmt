﻿using Microsoft.AspNetCore.Mvc;
using SecondApp.Models;

namespace SecondApp.Controllers
{
    public class ToolController : Controller
    {
        public IActionResult PrintNumbers()
        {
            return View();
        }

        public IActionResult Table()
        {
            Student student1 = new()
            {
                Name = "Bishnu",
                Email = "Bishnu@gmail.com",
                Address = "Ktm",
                Phone = "834095375357"
            };

            Student student2 = new()
            {
                Name = "Bishakha",
                Email = "Bishakha@gmail.com",
                Address = "Ktm",
                Phone = "401211375357"
            };

            Student student3 = new()
            {
                Name = "Prijesh",
                Email = "Prijesh@gmail.com",
                Address = "Ktm",
                Phone = "401211375357"
            };

            List<Student> students = new() { student1, student2, student3 };

            return View(students);
        }
    }
}
