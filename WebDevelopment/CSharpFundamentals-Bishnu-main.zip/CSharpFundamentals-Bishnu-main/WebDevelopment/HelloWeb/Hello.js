function showAlert() {
    alert("Hey there!!");
}