﻿using Microsoft.AspNetCore.Mvc;
using SchoolManagement.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace SchoolManagement.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        private static List<(int Id, string Name, string Address)> GetStudents()
        {
            // Use ADO.NET to fetch all students from DB
            List<(int Id, string Name, string Address)> students = new List<(int Id, string Name, string Address)>();
            string connectionString = @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=testdb;Integrated Security=True";
            SqlConnection con = new SqlConnection(connectionString);
            string query = "select * from student";

            SqlCommand cmd = new SqlCommand(query, con);
            try
            {
                con.Open();
                using SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    students.Add((Convert.ToInt32(reader[0]), reader[1].ToString(), reader[2].ToString()));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return students;
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}