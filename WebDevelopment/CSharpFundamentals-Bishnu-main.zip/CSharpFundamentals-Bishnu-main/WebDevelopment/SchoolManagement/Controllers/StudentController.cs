﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SchoolManagement.Data;
using SchoolManagement.Mapper;
using SchoolManagement.ViewModels;

namespace SchoolManagement.Controllers
{
    public class StudentController : Controller
    {
        // Tightly coupled
        //SchoolContext db = new SchoolContext();

        // Depedency Injection - loosely coupled code
        private readonly SchoolContext db;
        private readonly IWebHostEnvironment hostEnvironment;

        public StudentController(SchoolContext db, IWebHostEnvironment hostEnvironment)
        {
            this.db = db;
            this.hostEnvironment = hostEnvironment;
        }

        [HttpGet]
        public async Task<IActionResult> List()
        {
            var students = await db.Students.Where(s => s.Active == true).Include(x => x.Program).ToListAsync();  // select * from student
            var studentsViewModels = students.ToViewModel();
            return View(studentsViewModels);
        }

        [HttpGet]
        public async Task<IActionResult> Add()
        {
            var programs = await db.Programs.ToListAsync();
            ViewData["programs"] = programs.Select(x => 
                new SelectListItem 
                { 
                    Text = x.Name, 
                    Value = x.Id.ToString() 
                }).ToList();
            
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(StudentViewModel studentViewModel)
        {
            var student = studentViewModel.ToModel();

            if (student is null)
                return View("Error", new ErrorViewModel { Error = "Student could not be found/mapped" });

            student.ProfileImage = SaveProfileImage(studentViewModel.Avatar) ?? "Default.jpg";  // Null coalescing operator

            await db.Students.AddAsync(student);
            await db.SaveChangesAsync();

            return RedirectToAction("List");
        }

        private string? SaveProfileImage(IFormFile image)
        {
            if (image is null || image.Length <= 0)
                return null;

            var imageDirectory = Path.Combine(hostEnvironment.WebRootPath, "profile-images");
            Directory.CreateDirectory(imageDirectory);

            var fileName = $"{Guid.NewGuid()}_{image.FileName}";


            string filePath = Path.Combine(imageDirectory, fileName);

            // Save to directory
            using (Stream fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write))
            {
                image.CopyTo(fileStream);
            }

            return fileName;
        }

        public IActionResult Edit(int id)
        {
            var student = db.Students.Where(x => x.Id == id).Include(x => x.Program).FirstOrDefault();
            var studentViewModel = student?.ToViewModel();

            var programs = db.Programs.ToList();
            ViewData["programs"] = programs.Select(x =>
                new SelectListItem
                {
                    Text = x.Name,
                    Value = x.Id.ToString()
                }).ToList();

            if (studentViewModel is null)
                return View("Error", new ErrorViewModel { RequestId = "Edit", Error = $"Student with id {id} could not be found/mapped" });

            return View(studentViewModel);
        }

        [HttpPost]
        public IActionResult Edit(StudentViewModel studentViewModel)
        {
            var student = studentViewModel.ToModel();
            student.ProfileImage = SaveProfileImage(studentViewModel.Avatar) ?? studentViewModel.ProfileImage;

            db.Students.Update(student);
            db.SaveChanges();

            return RedirectToAction("List");
        }

        public IActionResult Delete(int id)
        {
            var student = db.Students.Find(id);
            return View(student?.ToViewModel());
        }

        [HttpPost]
        public IActionResult Delete(StudentViewModel studentViewModel)
        {
            //db.Students.Remove(student);
            var s = db.Students.Find(studentViewModel.Id);
            s.Active = false; // Soft delete

            db.SaveChanges();

            return RedirectToAction("List");
        }
    }
}
