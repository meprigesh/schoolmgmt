﻿School Management
- Students
- Lecturers
- Staffs
- Programs
- Semesters
- Subjects

- One program has multiple students
- One Program consist multiple semesters
- Single semester has multiple subjects




- Database Access

-- Relational databases: Oracle, Sql Server, SqLite, MySql, Postgres etc.
-- No-SQL Databases: MongoDb, DocumentDb etc

-- ADO.NET
-- ORM (Object Reletional Mapper) tool: EF Core, Dapper, NHibernate, RepoDb etc.



--EF Core Migrations

1. Code first approach

---- dotnet tool install dotnet-ef -g
---- dotnet ef migrations add Intial
---- dotnet ef database update

2. Database first approach

---code generator tool

