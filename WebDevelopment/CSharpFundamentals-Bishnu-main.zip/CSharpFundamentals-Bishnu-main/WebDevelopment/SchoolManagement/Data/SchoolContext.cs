﻿using Microsoft.EntityFrameworkCore;
using SchoolManagement.Models;

namespace SchoolManagement.Data
{
    public class SchoolContext: DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder
                .UseSqlServer(@"Data Source=(localdb)\mssqllocaldb;Initial Catalog=SchoolManagementDb;Integrated Security=True");
        }

        public DbSet<Student> Students { get; set; }
        public DbSet<Models.Program> Programs { get; set; }
        public DbSet<SchoolManagement.Models.Semester> Semester { get; set; }
    }
}
