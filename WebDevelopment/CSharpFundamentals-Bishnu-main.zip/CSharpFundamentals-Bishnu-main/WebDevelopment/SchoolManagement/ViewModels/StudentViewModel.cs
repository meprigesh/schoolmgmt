﻿using System.ComponentModel.DataAnnotations;

namespace SchoolManagement.ViewModels
{
    public class StudentViewModel
    {
        public int Id { get; set; }

        [Required]
        [MinLength(2, ErrorMessage = "First Name should be at least 2 chars")]
        [Display(Name = "Your First Name")]
        public string FirstName { get; set; }

        [Required]
        [MinLength(3)]
        public string LastName { get; set; }

        public string Name { get; set; }
        public string Address { get; set; }
        public DateTime Dob { get; set; }
        public char Gender { get; set; } = 'F';

        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        
        public string Phone { get; set; }
        public string Program { get; set; }
        public string Semester { get; set; }
        public string? Salutation { get; set; }
        public bool Active { get; set; } = true;
        public IFormFile Avatar { get; set; }
        public string ProfileImage { get; set; }
        public int ProgramId { get; set; }
    }
}
