﻿using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolManagement.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public DateTime Dob { get; set; }
        public char Gender { get; set; } = 'F';
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Semester { get; set; }
        public string? Salutation { get; set; }
        public bool Active { get; set; } = true;
        public string ProfileImage { get; set; }

        public Program Program { get; set; }
        public int ProgramId { get; set; }
    }
}
