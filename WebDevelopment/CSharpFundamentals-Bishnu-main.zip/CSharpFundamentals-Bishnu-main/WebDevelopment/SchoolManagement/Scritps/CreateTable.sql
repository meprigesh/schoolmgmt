﻿
CREATE TABLE Student (
    Id int not null PRIMARY KEY identity(1,1), --Primary Key
    Name nvarchar(50) not null,
    Address nvarchar(200),
    Email varchar(50),
    Dob datetime2,
    Gender char(1)
);