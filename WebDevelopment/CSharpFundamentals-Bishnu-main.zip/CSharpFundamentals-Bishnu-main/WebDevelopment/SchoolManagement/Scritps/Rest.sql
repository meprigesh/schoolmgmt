﻿-- Insert statement
insert into Student (Name, Address, Email, Dob, Gender)
values ('Reema Shrestha', 'Bhaktpur', 'ram.shrstha@gmail.com', '2010/5/12', 'F')

-- Update statement
update Student set Name='Lalit'
where Id = 4

-- Selection/projection
select * from student
where Gender = 'F'

-- Select all female studnets who lives in bhaktapur
select * from Student
where Gender='F' and Address like 'bhakt%'

-- Order students by their name
select * from Student
order by Name desc

-- Find number of students living in each city
select s.Address, COUNT(*) as NumberOfStudents 
from Student as s -- alias
group by Address


