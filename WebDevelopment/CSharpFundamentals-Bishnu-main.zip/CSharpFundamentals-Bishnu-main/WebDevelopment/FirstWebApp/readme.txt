
-> ASP (Active Server Pages) - Web Dev, like JSP

-> .NET Framework (4.8 latest), early 2000, windows only
-> Mono (Unity, Xamarin)

-> For desktop, Windows Froms
-> For web, ASP.NET (Web Forms)
-> MVC pattern, ASP.NET MVC (latest v5)

-> .NET Core, 2016 (Complete new framework, cross platform, open source)
-> last 3.1
-> Web - ASP.NET Core, MVC Pattern

-> 2020, .NET 5 (Unification)
-> .NET 6



URLs
https://www.google.com:1234/abcsdfsaf/sdfasf?x=12&y=bishnu


https://www.google.com:443/search?q=kathmandu&sxsrf=ALiCzsYnnPttoxBXNVAj7ECvCgv6vVj1yQ%3A1662515326974&source=hp&ei=fvgXY-qMOZ6PseMPj9mg-Ao&iflsig=AJiK0e8AAAAAYxgGjmpA6cm5wbsC142CJN6mwygglVDr&ved=0ahUKEwjqw_ubyIH6AhWeR2wGHY8sCK8Q4dUDCAc&uact=5&oq=kathmandu&gs_lcp=Cgdnd3Mtd2l6EAMyCwguEIAEELEDENQCMggIABCABBCxAzILCC4QgAQQsQMQgwEyCwgAEIAEELEDEIMBMgsIABCABBCxAxCDATIICAAQgAQQsQMyEQguEIAEELEDEIMBEMcBEK8BMgsILhCABBDHARCvATIFCAAQgAQyEQguEIAEELEDEIMBEMcBEK8BOgcIIxDqAhAnOgQIIxAnOgQILhAnOggIABCxAxCDAToICC4QgAQQsQM6DgguELEDEIMBEMcBEK8BOg4ILhCxAxCDARDHARDRAzoFCC4QgAQ6CAguELEDEIMBUK0DWLgRYPgeaABwAHgBgAHcA4gB4hWSAQkwLjEuNS4zLjGYAQCgAQGwAQo&sclient=gws-wiz
https://www.bing.com/search?q=kathmandu&qs=AS&pq=kathma&sk=AS1&sc=6-6&cvid=F0034411137649DBB731F2BB67301C62&FORM=QBLH&sp=2
https://duckduckgo.com/?q=kathmandu&t=h_&ia=web

Cipher Text

// private key

// public key (private, public), RSA

We are coming
zh2wed242fsfg3535sfdg535353dfsfs


http
https
ftp
ftps
file
















